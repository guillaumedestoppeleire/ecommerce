package com.formation.exceptions;

public class MetierException extends Exception {

    public MetierException(String message) {
        super(message);
    }

}
