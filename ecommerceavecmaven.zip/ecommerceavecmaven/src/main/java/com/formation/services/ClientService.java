package com.formation.services;

import com.formation.exceptions.MetierException;
import com.formation.models.Client;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ClientService {

    public static Client creerClient(String id, String email) throws MetierException {

        if (email == null || email.isEmpty()) {
            throw new MetierException("L'email ne peut être vide");
        } else if (!isValid(email)) {
            throw new MetierException("L'email n'est pas valide");
        }

        Client client = new Client();
        client.id = id;
        client.email = email;
        return client;
    }

    private static boolean isValid(String email) {
        final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

}
