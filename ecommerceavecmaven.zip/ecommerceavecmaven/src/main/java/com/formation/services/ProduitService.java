package com.formation.services;

import com.formation.exceptions.MetierException;
import com.formation.models.Produit;

public class ProduitService {

    public static Produit creerProduit(String id, String nom, float prixUnitaire) {

        Produit produit = new Produit();
        produit.id = id;
        produit.nom = nom;
        produit.prixUnitaire = prixUnitaire;
        return produit;
    }

}
