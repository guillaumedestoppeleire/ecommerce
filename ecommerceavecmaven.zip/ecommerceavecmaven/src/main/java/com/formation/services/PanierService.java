package com.formation.services;

import com.formation.models.Panier;

import java.util.ArrayList;
import java.util.List;

public class PanierService {

    private static List<Panier> paniers = new ArrayList<>();

    public static Panier getPanier(Client client)
}
