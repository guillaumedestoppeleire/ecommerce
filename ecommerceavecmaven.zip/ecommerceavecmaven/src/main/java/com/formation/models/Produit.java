package com.formation.models;

import java.util.List;

public class Produit {

    public String id;
    public String nom;
    public String description;
    public Float prixUnitaire;
    public List<String> images;
    public String categorie;
    public String url;
    public boolean isSupprime = false;

}
