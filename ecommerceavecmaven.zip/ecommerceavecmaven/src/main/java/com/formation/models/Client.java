package com.formation.models;

public class Client {

    public String id;
    public String email;
    public String motDePasse;
    public String adressePostale;
    public String telephone;
    public boolean isSupprime = false;

}
