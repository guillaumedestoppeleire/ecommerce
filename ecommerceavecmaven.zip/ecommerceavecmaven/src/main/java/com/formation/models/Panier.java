package com.formation.models;

import javafx.scene.input.InputMethodTextRun;

import java.time.LocalDate;
import java.util.List;

public class Panier {

    public String id;
    public Client client;
    public List<ProduitPanier> produits;
    public LocalDate date;

}
